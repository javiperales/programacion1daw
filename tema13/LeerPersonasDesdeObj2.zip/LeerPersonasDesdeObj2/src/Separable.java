
public interface Separable {
	default String getSeparador(){
		return ";";
	};
}
