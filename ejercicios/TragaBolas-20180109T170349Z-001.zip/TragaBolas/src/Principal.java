import java.util.*;
public class Principal {

	public static void main(String[] args) {

		String color;
		int bolasComidas, maxBolas, op=-1;

		Scanner teclado = new Scanner (System.in);

		do {
			System.out.println("�Qu� color va a tener el tragabolas?");
			color=teclado.nextLine();
		}while(!color.equals("Amarillo") && !color.equals("Rojo") && !color.equals("Azul") && !color.equals("Verde"));

		System.out.println("�Qu� m�ximo de bolas va a poder tragar este tragabolas?");
		maxBolas=teclado.nextInt();

		Tragabolas unTragabolas= new Tragabolas(color, maxBolas);

		do {
			System.out.println("1. Crear TragaBolas.");
			System.out.println("2. Darle de comer.");
			System.out.println("3. Hacerle dormir.");
			System.out.println("4. Trotar.");
			System.out.println("5. Ver estado.");
			System.out.println("0. Finalizar.");
			op=teclado.nextInt();

			switch(op) {

			case 1:
				teclado.nextLine(); // De este modo no nos va a pedir el color 2 veces, pues ya ha vaciado de alg�n modo lo que vale color	

				do {
					System.out.println("�Qu� color va a tener el tragabolas?");
					color=teclado.nextLine();
				}while(!color.equals("Amarillo") && !color.equals("Rojo") && !color.equals("Azul") && !color.equals("Verde"));

				System.out.println("�Qu� m�ximo de bolas va a poder tragar este tragabolas?");
				maxBolas=teclado.nextInt();

				unTragabolas= new Tragabolas(color, maxBolas);
				bolasComidas=0;

				break;
			case 2:
				unTragabolas.comer();
				break;
			case 3:
				unTragabolas.dormir();
				break;
			case 4:
				unTragabolas.trotar();
				break;
			case 5:
				unTragabolas.visualizar();
			}// switch

		}while(op!=0);

	}

}
