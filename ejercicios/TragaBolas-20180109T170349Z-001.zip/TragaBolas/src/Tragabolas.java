
public class Tragabolas {

	private String color;
	private int bolasComidas;
	private int maxBolas;


	Tragabolas(String color, int maxBolas){

		this.color=color;
		this.maxBolas=maxBolas;
		bolasComidas=0;

	}//constructor


	public void comer() {
		if (maxBolas>bolasComidas) {
			bolasComidas++;
			System.out.println("He comido una bola.");
		}else {
			System.out.println("Estoy lleno.");

		}

	}//comer

	public void dormir() {
		if(maxBolas==bolasComidas) {
			System.out.println("Tripa llena. ZZZZZZ");
			bolasComidas=bolasComidas/2;
		}else {
			System.out.println("No quiero dormir. A�n tengo hambre.");
		}

	}//dormir

	public void trotar() {
		if (bolasComidas>=1) {
			bolasComidas--;
			System.out.println("Estoy trotando.");
		}else {
			System.out.println("Estoy vac�o. No tengo fuerzas.");
		}

	}//trotar

	public void visualizar() {

		System.out.println("El tragabolas de color "+color + " ha comido " + bolasComidas + " bolas, pudiendo comer un total de "+maxBolas+".");

	} //visualizar

} //class
