import java.util.Scanner;

public class Ej03Principal {

	public static void main(String[] args) {
		int num;
		Scanner teclado = new Scanner (System.in);
		System.out.println("Dame un n�mero");
		num=teclado.nextInt();
		
		MetodosEstaticos.factorial(num);
	}

}
