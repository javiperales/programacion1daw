import java.util.*;
public class Ej05Principal {

	public static void main(String[] args) {

		Scanner teclado = new Scanner (System.in);

		int n,m;
		
		System.out.println("Dame un n�mero");
		n=teclado.nextInt();
		System.out.println("Dame otro n�mero");
		m=teclado.nextInt();

		MetodosEstaticos.mcd(n, m);
	}

}
