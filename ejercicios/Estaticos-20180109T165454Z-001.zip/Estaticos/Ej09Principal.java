import java.util.Scanner;

public class Ej09Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		
		  double a,b,c;
		  double [] resultados=new double[2];
		  
		  System.out.println("Introduce a");
		  a=teclado.nextDouble();
		  System.out.println("Introduce b");
		  b=teclado.nextDouble();
		  System.out.println("Introduce c");
		  c=teclado.nextDouble();
		
		 MetodosEstaticos.segGrado(a, b, c);
		 resultados= MetodosEstaticos.segGrado(a,b,c);
		
		System.out.println(resultados[0]);
		System.out.println(resultados[1]);
	
	}

}
