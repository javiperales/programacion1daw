import java.util.*;
public class Ej02Principal {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		int p=-1, q=-1;
		
		MetodosEstaticos.divisores(p, q);
	}

}
