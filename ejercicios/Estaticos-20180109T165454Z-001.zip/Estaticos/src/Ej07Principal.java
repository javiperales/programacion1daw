import java.util.Scanner;

public class Ej07Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		
		int r;
		do{
			System.out.println("Dame un radio");
			r=teclado.nextInt();

		}while (r<0);
		
		MetodosEstaticos.radio(r);
	}

}
