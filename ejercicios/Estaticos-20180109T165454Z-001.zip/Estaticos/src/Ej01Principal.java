import java.util.*;
public class Ej01Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		int num;
		System.out.println("Dame un n�mero");
		num = teclado.nextInt();
		
		MetodosEstaticos.primo(num);
		
		
		
		/*if(MetodosEstaticos.primo(num)){
			System.out.println("Es primo");
		}else{
			System.out.println("No es primo");
		}*/
	}

}
