import java.util.*;
public class MetodosEstaticos {


	public static boolean primo(int num){

		boolean esPrimo=true;
		int otroNum=2;

		while(esPrimo==true && otroNum<num){
			if (num%otroNum==0) {
				esPrimo=false;
			}else{
				otroNum++;
			}//if

		}//while
		if (esPrimo==true){
			System.out.println("Es primo.");
			return true;
		}else{
			System.out.println("No es primo");
			return false;
		}

	}//esPrimo

	public static void divisores(int p, int q){
		Scanner teclado = new Scanner (System.in);
		int contaP=1, contaQ=1; 
		// no va a dividir entre 1 pero todos pueden asi que se considera como uno de sus divisores.
		do{
			System.out.println("Dame un n�mero");
			p=teclado.nextInt();
			System.out.println("Dame otro n�mero");
			q=teclado.nextInt();
		}while(p<0 || q<0);

		for (int k=1; k < p; k++){
			if (p%k==0){
				contaP++;
			}
		}//for P
		for (int k=1; k < q; k++){
			if (q%k==0){
				contaQ++;
			}
		}//for Q
		System.out.println("P tiene "+ contaP  + " divisores.");
		System.out.println("Q tiene "+ contaQ  + " divisores.");
		//Math.max(p, q);
		if (contaP > contaQ){
			System.out.println("P tiene mas divisores que Q");
		}
		else if (contaQ>contaP){
			System.out.println("Q tiene mas divisores que P");
		}
		else if (contaQ == contaP){
			System.out.println("P tiene los mismos divisores que Q");
		}

	}//divisores

	public static void factorial (int n){
		Scanner teclado = new Scanner (System.in);
		int factorial=1;
		while (n<0){
			System.out.println("Dame un n�mero");
			n=teclado.nextInt();

		}//while
		for (int i=n; i>0; i--){
			factorial=factorial*i;

		}//for
		System.out.println("El factorial de "+n+ " es "+factorial);

	}//factorial

	public static void listaPrimos(int n){
		Scanner teclado = new Scanner (System.in);

		int conta;

		while (n<0){
			System.out.println("Dame un n�mero");
			n=teclado.nextInt();

		}//while

		for(int i=1; i<=n; i++){
			conta=0;
			for(int k=2; k<=i-1; k++){
				if (i % k==0){
					conta=conta+1;
				}//if
			}//for
			if (conta==0){
				System.out.println(i);
			}//if
		}//for
	}//listaPrimos --> En todo caso si queremos hacerlo utilizando el filtro del anterior ejercicio, ser�a almacenar en un vector cada ocurrencia.

	public static void mcd (int n, int m){
		int i, max=0;
		Scanner teclado = new Scanner (System.in);

		while (n <0 || m <0){
			System.out.println("Dame un n�mero");
			n=teclado.nextInt();
			System.out.println("Dame otro n�mero");
			m=teclado.nextInt();
		}//while

		for (i=1; i<=n; i++){ //nos da igual cual sea, pues no puede ser un divisor com�n mayor a uno de los dos n�meros.
			if (n%i==0 && m%i==0){
				max= i; //el �ltimo por el que puedan dividirse ambos.

			}
		}
		System.out.println("El m�ximo com�n divisor (mcd) es: "+ max);

	}//mcd

	public static void mcm (int n, int m){
		int i = 0, min=0, max=0;
		boolean fin=false;
		Scanner teclado = new Scanner (System.in);

		while(fin==false){

			i=m;
			if (i%m==0 && i%n ==0){

				fin=true;
				min =i;
			}
			i++;
		}

		System.out.println("El mcm es: "+ min);
	}//mcm

	public static void radio(int r){
		Scanner teclado = new Scanner (System.in);
		int op=-1;
		final double PI=3.14159265358979323846;
		double radio=0;

		do{
			System.out.println("1. Longitud de c�rculo.");
			System.out.println("2. Superficie del c�rculo.");
			System.out.println("3. Volumen de esfera.");
			System.out.println("0. Finalizar.");
			op=teclado.nextInt();
			switch(op){

			case 1:
				radio=(2*PI*r);
				System.out.println(radio);
				radio=0;
				break;
			case 2:
				radio=PI*(r*r);
				System.out.println(radio);
				radio=0;
				break;
			case 3:
				radio=4/3*PI*(r*r*r);
				System.out.println(radio);
				radio=0;
				break;

			}//switch

		}while (op!=0);

	}//radio

	public static void combinaciones(int n, int m){

		Scanner teclado = new Scanner (System.in);

		int factorialN=1, factorialM=1, factorialA=1, result;

		for (int i=n; i>0; i--){
			factorialN=factorialN*i;
		}
		for (int k=m; k>0; k--){
			factorialM=factorialM*k;
		}
		for (int a=m-n; a>0; a--){
			factorialA=factorialA*a;
		}
		result=factorialM/(factorialN * factorialA);
		System.out.println(result);

	}//combinaciones

	public static double[] segGrado(double a, double b, double c){

		double resultPos, resultNeg;
		
		double [] resultados=new double[2];
	
		resultPos= (-b + Math.sqrt(b*b)+(-4*a*c))/(2*a);
		resultNeg= (-b - Math.sqrt(b*b)+(-4*a*c))/(2*a);
		
		resultados[0]= resultPos;
		resultados[1]= resultNeg;
		return resultados;
		
		
	}//segGrado
	
}//class
