import java.util.Scanner;

public class Ej08Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		int n,m;
		
		do{
			System.out.println("Dame un n�mero.");
			n=teclado.nextInt();
			System.out.println("Dame un n�mero mayor al anterior.");
			m=teclado.nextInt();
			
		}while (m<n);
		
		MetodosEstaticos.combinaciones(n, m);
	}

}
