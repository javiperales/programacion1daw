import java.util.Scanner;

public class Ej06Principal {

	public static void main(String[] args) {
		Scanner teclado = new Scanner (System.in);
		int n,m;
		do{
			System.out.println("Introduce n�mero");
			n=teclado.nextInt();
			System.out.println("Introduce n�mero mayor que el anterior.");
			m=teclado.nextInt();
		}while((n<0 && m<0) || m<n);
		
		MetodosEstaticos.mcm(n, m);
		
	}

}
