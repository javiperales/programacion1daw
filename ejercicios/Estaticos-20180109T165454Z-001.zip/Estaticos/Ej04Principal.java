import java.util.Scanner;

public class Ej04Principal {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner (System.in);
		int num;
		System.out.println("Introduce un n�mero.");
		num=teclado.nextInt();

		MetodosEstaticos.listaPrimos(num);
	}

}
