import java.util.Scanner;

public class TerceroB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado;
		teclado = new Scanner(System.in);
		String cadenaLee;//donde se lee
		int suma=0;// donde se suma
		char digito;//cada caracter
		System.out.println("�Cadena?");
		cadenaLee=teclado.nextLine();//leemos la cadena
		for (int i = 0; i < cadenaLee.length(); i++) {//recorre la cadena para tratar cada caracter
			digito = cadenaLee.charAt(i);//caracter de la posici�n i
			switch (digito){
			case '9':
				suma++;
			case '8':
				suma++;
			case '7':
				suma++;
			case '6':
				suma++;
			case '5':
				suma++;
			case '4':
				suma++;
			case '3':
				suma++;
			case '2':
				suma++;
			case '1':
				suma++;
			}
		}
		System.out.println("La suma de los d�gitos num�ricos es: "+suma);//escribe la suma

	}

}
