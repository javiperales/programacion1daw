import java.util.Scanner;

/**
 * Pide una cadena por teclado, genera otra cadena en la que 
 * aparece dos veces cada car�cter de la cadena que se ha 
 * pedido por teclado y la muestra en pantalla. Ejemplo:
 * Si damos la cadena �Hola� debe generar y mostrar en
 * pantalla la cadena �HHoollaa�.
 */

public class Segundo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado;
		teclado = new Scanner(System.in);
		String cadenaLee;//donde se lee
		String cadenaSale="";// donde se escribe
		System.out.println("�Cadena?");
		cadenaLee=teclado.nextLine();//leemos la cadena
		for (int i = 0; i < cadenaLee.length(); i++) {//recorre la cadena para ir duplicando los caracteres
			cadenaSale=cadenaSale+cadenaLee.charAt(i)+cadenaLee.charAt(i);
		}
		System.out.println(cadenaSale);//escribe la salida
	}

}
