/**
 * 1)	Programa que calcule las calificaciones obtenidas en un examen 
 * de test por un grupo de 5 alumnos.
 * El examen consta de 10 preguntas de test con 4 posibles respuestas 
 * (A, B, C y D) y la plantilla de la soluci�n es la siguiente:
 * Pregunta	1	2	3	4	5	6	7	8	9	10
 * Soluci�n	B	D	A	C	B	C	A	C	B	D
 * 
 * La calificaci�n se calcular� con la siguiente ponderaci�n:  
 *  NOTA = ACERTADAS - FALLADAS * 0.3
 *  El programa debe hacer lo siguiente:
 *  Generar aleatoriamente la respuesta a cada pregunta para cada alumno. 
 *     Suponemos que no dejar� ninguna pregunta en blanco.
 *     Mostrar un listado como el siguiente (con este formato)
 */
public class PrimeroC {
	public static void main(String[] args) {
		final char[] plantilla = new char[]{'B','D','A','C','B','C','A','C','B','D'};

		final int MAX_ALUMNOS =5;
		final int NUM_RESPUESTAS = 10;

		int aleatorio;
		int[] aciertos = new int[MAX_ALUMNOS];
		int[] errores = new int[MAX_ALUMNOS];
		char[][] alumno = new char[MAX_ALUMNOS][NUM_RESPUESTAS];
		//Ponemos a cero el vector que va a contar el n�mero de aciertos por alumno
		for(int alu=0;alu<MAX_ALUMNOS;alu++){
			aciertos[alu]=0;
			errores[alu]=0;
		}
		//Generamos aleatoriamente las respuestas de los alumnos
		for(int alu=0;alu<MAX_ALUMNOS;alu++){
			for(int resp=0;resp<NUM_RESPUESTAS;resp++){
				aleatorio = (int)(Math.random()*4);
				/*Al sumarle 65 hacemos que empiece desde el codigo ASCII de la A mayuscula, por lo que puede ser
				 A B C � D el resultado que salga, ya que el numero aleatorio valdra de 0 a 3.
				 */
				alumno[alu][resp] = (char)(aleatorio+65);
				/*Si la respuesta que ha dado el alumno coincide con la que hay en la plantilla
				 *suma 1 al numero de aciertos de dicho alumno,
				 *en caso contrario suma 1 al numero de errores
				 */
				if(alumno[alu][resp]==plantilla[resp]){
					aciertos[alu] +=1;
				}else{
					errores[alu]+=1;
				}
			}

		}//Fin generaci�n de respuestas y comprobar aciertos


		//Formateo de la impresi�n por pantalla
		System.out.print("Soluci�n:\t");
		for(int resp=0;resp<NUM_RESPUESTAS;resp++){
			System.out.printf("%2c ",plantilla[resp]);
		}
		System.out.println("\tAciertos \tFallos \t\tCalificaci�n\n");
		for(int alu=0;alu<MAX_ALUMNOS;alu++){
			System.out.print("Alumno "+ (alu+1)+"\t");
			for(int resp=0;resp<NUM_RESPUESTAS;resp++){
				System.out.printf("%2c ",alumno[alu][resp]);
			}
			System.out.print("\t"+aciertos[alu]+"\t\t"+errores[alu]+"\t\t");
			//C�lculo de la nota del alumno e impresi�n
			System.out.printf("%6.2f",((aciertos[alu])-(errores[alu]*0.3)));
			System.out.println();
		}

	}
}
