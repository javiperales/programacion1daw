import java.util.Scanner;

/**
 * programa que pida una cadena de caracteres por teclado y a 
 * continuaci�n muestre en pantalla la suma de todos los d�gitos 
 * num�ricos que aparezcan en dicha cadena
 */

/**
 * @author yo
 *
 */
public class Tercero {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado;
		teclado = new Scanner(System.in);
		final String NUMEROS="0123456789"; //cadena con los n�meros en secuencia
		String cadenaLee;//donde se lee
		int suma=0, digito;// donde se suma y la posici�n en numeros
		System.out.println("�Cadena?");
		cadenaLee=teclado.nextLine();//leemos la cadena
		for (int i = 0; i < cadenaLee.length(); i++) {//recorre la cadena para tratar cada caracter
			digito = NUMEROS.indexOf(cadenaLee.charAt(i));//caracter de la posici�n i
			if (digito>0){// si encuentra el d�gito, la posici�n es el n�mero
				suma = suma+digito;
			}
		}
		System.out.println("La suma de los d�gitos num�ricos es: "+suma);//escribe la suma

	}

}
