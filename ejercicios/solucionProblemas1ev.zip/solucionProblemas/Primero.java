/**
 * 1)	Programa que calcule las calificaciones obtenidas en un examen 
 * de test por un grupo de 5 alumnos.
 * El examen consta de 10 preguntas de test con 4 posibles respuestas 
 * (A, B, C y D) y la plantilla de la soluci�n es la siguiente:
 * Pregunta	1	2	3	4	5	6	7	8	9	10
 * Soluci�n	B	D	A	C	B	C	A	C	B	D
 * 
 * La calificaci�n se calcular� con la siguiente ponderaci�n:  
 *  NOTA = ACERTADAS - FALLADAS * 0.3
 *  El programa debe hacer lo siguiente:
 *  Generar aleatoriamente la respuesta a cada pregunta para cada alumno. 
 *     Suponemos que no dejar� ninguna pregunta en blanco.
 *     Mostrar un listado como el siguiente (con este formato)
 */


public class Primero {

	
	public static void main(String[] args) {
		
		final String RESPUESTAS = "ABCD"; //respuestas posibles
		final String SOLUCION = "BDACBCACBD";//soluci�n correcta del test
		String respuestasAlumnos[] = new String[5];//las cinco ejecuciones del test
		float calificacion=0;
		int aciertos, fallos;// donde se suman aciertos y fallos
		//Imprimir cabecera
		System.out.print(" Soluci�n:    ");
		for (int i = 0; i < SOLUCION.length(); i++) {
			System.out.print(" "+SOLUCION.charAt(i));
		}
		//imprime cabecera de respuestas y resultados
		System.out.println("\n                                       Aciertos    Fallos  Calificaci�n");
		//Generar soluciones e imprimirlas
		for (int i = 0; i < 5; i++) {//para cada alumno
			aciertos=fallos=0;//inicializo datos
			respuestasAlumnos[i]="";//inicaliza elemento de vector
			System.out.print("\n Alumno  "+(i+1)+":   ");//imprime comienzo de l�nea
			for (int j = 0; j < SOLUCION.length(); j++) {//recorre la cadena para tratar cada respuesta
				respuestasAlumnos[i]=respuestasAlumnos[i]+RESPUESTAS.charAt((int) (Math.random()*4));//respuesta aleatoria
				if (SOLUCION.substring(j,j+1).equals(respuestasAlumnos[i].substring(j, j+1))){// compara respuesta con SOLUCION
					aciertos++;//suma aciertos
				}else{
					fallos++;//suma fallos
				}
				System.out.print(" "+respuestasAlumnos[i].charAt(j));
			}
			calificacion= aciertos-fallos*0.3f;//calcula resultado
			System.out.printf("         %2d        %2d        %6.2f",aciertos,fallos,calificacion);//escribe resultado
		}
	}
}
