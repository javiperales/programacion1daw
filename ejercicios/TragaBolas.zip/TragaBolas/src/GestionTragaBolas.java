
import java.util.Scanner;

public class GestionTragaBolas {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner teclado = new Scanner(System.in);
		String color;
		Integer maxBolas;
		TragaBolas miTragaBolas = null;

		int opcion;
		do {
			if (miTragaBolas == null) {
				System.out.println("1: Crear Tragabolas.\n0: Fin.");

			} else {
				System.out.println("\n2: Darle de comer. " + "\n3: Trotar. " + "\n4: Hacerle dormir. "
						+ "\n5: Ver estado. " + "\n0: Fin.");
			}
			System.out.println("Elija opcion");
			opcion = teclado.nextInt();
			// Crear TragaBolas
			if (opcion == 1 && miTragaBolas == null) {
				teclado.nextLine();//limpiamos buffer del teclado
				System.out.println("Color del tragaBolas (amarillo/azul/verde/rojo)");
				color = teclado.nextLine();
				while (color.equals("amarillo") == false && color.equals("azul") == false
						&& color.equals("verde") == false && color.equals("rojo") == false) {
					System.out.println("Color del tragaBolas (amarillo/azul/verde/rojo)");
					color = teclado.nextLine();
				}

				System.out.println("Numero maximo de bolas");
				maxBolas = teclado.nextInt();

				miTragaBolas = new TragaBolas(color, maxBolas);
			} else if (miTragaBolas != null) {// si el tragabolas ya est� creado

				// Resto de opciones
				switch (opcion) {

				case 2:
					miTragaBolas.comer();
					break;
				case 3:
					miTragaBolas.trotar();
					break;
				case 4:
					miTragaBolas.dormir();
					break;
				case 5:
					miTragaBolas.visualizar();
					break;
				}
			}
		} while (opcion != 0);

	}// main
}// class
