
import java.util.Scanner;

public class TragaBolas {
	private String color;
	private Integer maxBolas;
	private Integer bolasComidas;

	public TragaBolas() {

	}

	// si el color que se pasa como par�metro no es v�lido, por defecto se asigna el rojo
	public TragaBolas(String color, Integer maxBolas) {
		if (color.equalsIgnoreCase("amarillo") || color.equalsIgnoreCase("azul") || color.equalsIgnoreCase("verde") || color.equalsIgnoreCase("rojo")) {
			this.color = color;
		}else{
			this.color = "rojo";
		}
		this.maxBolas = maxBolas;
		bolasComidas = 0;
	}

	public void visualizar() {
		System.out.println( "El color es " + color + " el numero maximo de bolas es " + maxBolas + " y lleva comidas un total de "
				+ bolasComidas );
	}

	public void comer() {
		if (bolasComidas < maxBolas) {
			bolasComidas++;
			System.out.println( "He comido una bola." );
		} else {
			System.out.println( "No puedo comer mas" );
		}
	}

	public void trotar() {
		if (bolasComidas >= 1) {
			bolasComidas--;
			System.out.println( "Estoy trotando" );
		} else {
			System.out.println( "No puedo trotar mas" );
		}
	}

	public void dormir() {
		if (bolasComidas == maxBolas) {
			bolasComidas = bolasComidas / 2;
			System.out.println( "Tripa llena. ZZZZZZ");
		} else {
			System.out.println("No quiero dormir");
		}
	}
}