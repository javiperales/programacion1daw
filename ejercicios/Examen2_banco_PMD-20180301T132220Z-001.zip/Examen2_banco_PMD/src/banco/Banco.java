package banco;

/**
 * 
 * @author Jose Ram�n Casado Solana (PMD)
 *
 */
public class Banco {
	/**
	 * Men� de programa
	 * @param opcion de mostrar
	 * @param cue numero cuenta
	 */
	public static void menu(final int opcion,final int cue){
		switch(opcion){
		case 1:
			sysout("1.- Crear cuenta");
			break;
		case 2:		
			sysout("2.- Elegir cuenta");
			sysout("3.- Asignar cliente a cuenta "+cue);
			sysout("4.- Quitar cliente de cuenta "+cue);
			sysout("5.- Ingresar dinero "+cue);
			sysout("6.- Sacar dinero "+cue);
			sysout("7.- Liquidar intereses");
			sysout("8.- Imprimir cuentas");
			sysout("9.- Ver cuenta "+cue);

			break;
		case 3:			
			sysout("2.- Elegir cuenta");
			sysout("7.- Liquidar intereses");
			sysout("8.- Imprimir cuentas");
			break;
		default:
			break;


		}

	}

	/**
	 * Main
	 * @param args
	 */
	public static void main(String[] args) {
		final int NUMCLI=10;//clientes a crear
		final int NUMCUE=6;//cuentas a crear
		final int MAXCUE=5;
		Cliente[] lista=new Cliente[NUMCLI];
		AbstractCuenta[] cuentas=new AbstractCuenta[NUMCUE];
		creaClientes(lista);
		int ncuenta=0;//contador de cuentas
		int cue=-1;//n�mero de cuenta
		int cli;//n�mero de cliente
		int tcue;//tipo de cuenta
		int opcion;//opci�n de men�
		float importe;//impoete a sacar ingresar
		do {//men�
			menu(1,cue);
			if (ncuenta>0){
				if(cue>-1){
					menu(2,cue);
				}else{
					menu(3,cue);
				}
			}
			sysout("0.- Salir");			
			opcion=CLeer.pedirEnteroValidar("Elije opci�n");
			switch (opcion) {//acciones de men�
			case 1://
				if (ncuenta>MAXCUE){
					sysout(" Alcanzado el n�mero m�ximo de cuentas ");
				}else {
					cli=verClientes(NUMCLI,lista);
					do{//escoge tipo de cuenta
						tcue=CLeer.pedirEnteroValidar("Escoge cuenta: 1.- Cuenta Corriente / 2.- Fondo de Inversi�n / 3.- Cuenta Vivienda");
					} while(tcue<0 || tcue>3);					
					creaCuentas(cuentas,ncuenta,lista,cli,tcue);					
					ncuenta=ncuenta+1;
					sysout("---------------");
				}
				break;

			case 2:
				if(ncuenta>0){
					cue=verCuentas(ncuenta, cuentas);
				}else{
					sysout("No existen cuentas corrientes");
				}
				break;

			case 3://a�adir cliente	
				if(ncuenta>0 && cue>-1){
					cli=verClientes(NUMCLI,lista);
					cuentas[cue].agregarCliente(lista[cli]);
				}
				break;
			case 4://Eliminar cliente	
				if(ncuenta>0 && cue>-1){
					cli=verClientes(NUMCLI,lista);
					cuentas[cue].eliminarCliente(lista[cli]);
				}
				break;
			case 5://Ingresar dinero
				if(ncuenta>0 && cue>-1){
					do{
						importe=CLeer.pedirFloat("Introduce el importe en euros a ingresar");
					} while(importe<0);
					if (importe>0){
						cuentas[cue].ingresar(importe);
					}
				}
				break;
			case 6://Sacar dinero	
				if(ncuenta>0 && cue>-1){
					do{
						importe=CLeer.pedirFloat("Introduce el importe en euros a sacar");
					} while(importe<0);
					if (importe>0){
						cuentas[cue].sacar(importe);
					}
				}
				break;
			case 7: //Liquidar intereses
				if(ncuenta>0){
					for (int i=0;i<AbstractCuenta.contador-1;i++){
						cuentas[i].liquidacionMensual();
					}
					sysout("Liquidaci�n realizada");
				}
				break;
			case 8://Imprimir cuentas
				if(ncuenta>0){
					for (int i=0;i<AbstractCuenta.contador-1;i++){
						sysout(cuentas[i].imprimirCuentas());
					}
				}
				break;
			case 9://Mostrar una cuenta
				if(ncuenta>0 && cue>-1){
					sysout(cuentas[cue].imprimirCuentas());
					for (int i=1; i<cuentas[cue].getTitulares();i++){
						sysout("titular "+i+" "+cuentas[cue].getTCliente(i) );
					}
				}
				break;
			default:
				sysout("Opcion incorrecta.");
				break;

			}

		} while(opcion!=0);
	}


	/**
	 * M�todo par imprimir por pantalla
	 * @param frase parametro donde se recibe lo que se va a imprimir por pantalla.
	 */
	public static void sysout(final String frase){
		System.out.println(frase);
	}
	/**
	 * Metodo para crear clientes de forma autom�ticca
	 */
	public static void creaClientes(Cliente ... lista){
		lista[0]=new Cliente("Jorgito","Don");
		lista[1]=new Cliente("Juanito","Dona");
		lista[2]=new Cliente("Jaimito","Donald");
		lista[3]=new Cliente("Daisy","Donad");
		lista[4]=new Cliente("Alejandra","Doald");
		lista[5]=new Cliente("Laura","Onald");
		lista[6]=new Cliente("Antonio","Cebollo");
		lista[7]=new Cliente("Alejandro","Molesto");
		lista[8]=new Cliente("Jose","Altivo");
		lista[9]=new Cliente("Alberto","Pasota");
	}
	/**
	 * Creamos las cuentas con este m�todo
	 * @param cuentas ah� le pasamos el vector de cuentas
	 * @param ncuenta ah� le pasamos el n�mero de cuenta
	 * @param lista le pasamos la lista de clientes
	 * @param cli pasamos el n�mero de cliente
	 * @param opcion con esto seleccionamos el tipo de cuenta a crear
	 */
	public static final void creaCuentas(final AbstractCuenta[] cuentas,final int ncuenta,final Cliente[] lista,final int cli,final int opcion){
		switch(opcion){
		case 1:
			cuentas[ncuenta]=new CuentaCorriente(lista[cli]);
			break;
		case 2:
			cuentas[ncuenta]=new FondoInversion(lista[cli]);
			break;
		case 3:
			cuentas[ncuenta]=new CuentaVivienda(lista[cli]);
			break;
		default: 
			break;
		}
	}
	/**
	 * lista de clientes
	 * @param ncli numero de clientes
	 * @param lista vector de clientes
	 * @return
	 */
	public static final int verClientes(final int ncli, final Cliente ... lista){
		int cli;
		for (int i=0; i<ncli; i++){
			sysout(i+" "+lista[i].getCliente());

		}
		sysout("---------------");
		do{//escoge cliente de la lista
			cli=CLeer.pedirEnteroValidar("Escoge el cliente");
		} while(cli<0 || cli>=ncli);
		return cli;
	}
	/**
	 * lista de cuentas
	 * @param ncuenta n�mero de cuentas creadas
	 * @param cuentas vector con las cuentas
	 * @return
	 */
	public static final int verCuentas(final int ncuenta,final AbstractCuenta ... cuentas){
		int cue;
		for (int i=0; i<ncuenta; i++){
			sysout(i+" "+cuentas[i].getCuenta()+" / ");
			if ((i+1)%5==0){
				sysout("");
			}
		}
		sysout("---------------");
		do{//escoge cuenta de la lista
			cue=CLeer.pedirEnteroValidar("Escoge la cuenta");
		} while(cue<0 || cue>=ncuenta);
		return cue;
	}
	
	
}