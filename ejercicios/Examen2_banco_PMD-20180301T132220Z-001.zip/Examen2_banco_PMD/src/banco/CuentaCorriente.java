package banco;

/**
 * @author usuario
 *
 */
public class CuentaCorriente extends AbstractCuenta {
	/**
	 * Interes 0.12% anual
	 */
	private static float interes=0.0012f; //En porcentaje
	/**
	 * Comision 0.60� mensual
	 */
    private static float comision=0.6f; // En euros
    /**
     * Cada 6� ingreso 1 punto
     */
    private transient int puntos;
    
	/**
	 * Constructor sin parametros
	 */
	public CuentaCorriente() {
		super();
		this.puntos=0;
	}
/**
 * Constructor CuentaCorriente
 * @param cliente 
 */
	public CuentaCorriente(final Cliente cliente){
		super();
		super.setCliente(0, cliente);
		this.titulares=1;
		this.puntos=0;
	}
	
	/**
	 * Ver cuenta
	 */
	@Override
	public String getCuenta(){
		return "Cuenta Corriente "+super.getNumero();
	}
	
	/**
	 * Metodo ingresar
	 */
	@Override
	public void ingresar(final float importe) {

		int paraPuntos;
		super.setSaldo(super.getSaldo()+importe);
		paraPuntos = (int) importe/6;
		this.puntos=this.puntos+paraPuntos;
	
	}
	
	/**
	 * Metodo sacar
	 */
	@Override
	public float sacar(final float importe) {		
		float imp;
		imp=importe;
		if(super.getSaldo()-imp<0){
			imp=super.getSaldo();
			System.out.println("No hay importe suficiente. Solo sacar� "+imp);
		}
		super.setSaldo(super.getSaldo()-imp);
		return imp;
	}

	/**
	 * Liquidaci�n menusal 
	 */
	@Override
	public float liquidacionMensual() {
		
		float interesMes;
		interesMes=super.getSaldo()*(this.interes/12)-this.comision;
		if(interesMes<0){
			sacar(-interesMes);
		}else {
			ingresar(interesMes);
		}
		return interesMes;
	}

	/**
	 * Imprimir cuentas
	 */
	@Override
	public String imprimirCuentas() {

		return "N�mero de cuenta "+super.getNumero()+", Titular 0 "+super.getTCliente(0)+", Cuenta Corriente - saldo: "+super.getSaldo()+", Puntos "+this.puntos;
	}
}