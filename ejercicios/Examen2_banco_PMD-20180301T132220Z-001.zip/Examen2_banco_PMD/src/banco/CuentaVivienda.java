package banco;
/**
 * @author yo
 *
 */
public class CuentaVivienda extends AbstractCuenta {
	/**
	 * Interes 0.24% anual
	 */
	private static float interes=0.0024f; //En porcentaje
	/**
	 * Sin comision
	 */
    private static float comision; // En euros

	/**
	 * 
	 */
	public CuentaVivienda() {
		super();
	}
/**
 * Constructor con parametros
 * @param cliente
 */
	public CuentaVivienda(final Cliente cliente) {
		super();
		super.setCliente(0, cliente);
		this.titulares=1;
	}
	
	/**
	 * Metodo informacion de cuenta
	 * Devuelve tipo de cuenta y numero de cuenta
	 */
	@Override
	public String getCuenta() {
	
		return "Cuenta Vivienda "+super.getNumero();
	}

	/**
	 * Metodo para ingresar 
	 */
	@Override
	public void ingresar(final float importe) {

		super.setSaldo(super.getSaldo()+importe);
	}

	/**
	 * Sacar dinero
	 */
	@Override
	public float sacar(final float importe) {
		
		System.out.println("De esta cuenta no se puede sacar dinero");
		return 0;
	}

	/**
	 * Liquidacion mensual
	 */
	@Override
	public float liquidacionMensual() {

		float interesMes;
		interesMes=super.getSaldo()*(this.interes/12)-this.comision;

		if(interesMes<0){
			sacar(-interesMes);
		}else {
			ingresar(interesMes);
		}
		return interesMes;
	}

	/**
	 * Metodo para imprimir cuentas
	 */
	@Override
	public String imprimirCuentas() {

		return "N�mero de cuenta "+super.getNumero()+", Titular 0 "+super.getTCliente(0)+", Cuenta Vivienda - saldo: "+super.getSaldo();
	}
}