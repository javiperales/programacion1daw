package banco;

// Completa las declaraciones siguientes
/**
 * Clase abstracta Cuenta
 * @author Jose Ram�n Casado Solana (PMD)
 *
 */
public abstract class AbstractCuenta {
    
	/**
	 * N�mero m�ximo de titulares que puede tener la cuenta
	 */
    public static final int TITULARES = 4;
    /**
     * Es el contador que asigna el n�mero de cuenta a la cuenta
     */
    protected static int contador=1;//para n�mero de cuenta
    /**
     * Es el n�mero m�nimo de titulares que debe de haber para eliminar un titular
     */
    private final static int MINTITULARES = 2;
    
    /**
     * 
     */
    private transient int numero;
    /**
     * Almacena el saldo de la cuenta
     */
    private float saldo; // En euros
    /**
     * Vector donde se almacenan los titulares de una cuenta
     */
    private transient Cliente [] clientes; // Lista de titulares de la cuenta
    /**
     * n�mero total de los titulares
     */
    protected int titulares;  

//metodos de Cuenta:
    /**
     * Es el constructor por defecto de Cuenta y nos permite inicializar el contador, 
     * a�adir un nuevo cliente y pone el saldo a 0.
     */
    public AbstractCuenta(){
    	this.numero=this.contador;
    	this.contador++;
    	this.clientes = new Cliente[TITULARES];
    	this.saldo=0;
    }
/**
 * Nos devuelve el valor del contador
 * @return
 */
    public int getContador(){
    	return this.contador;
    }
    /**
     * M�todo para obtener los titulares de una cuenta
     * @return
     */
    public int getTitulares(){
    	return this.titulares;
    }
    /**
     * M�todo para insertar un valor al contador
     * @param contador
     */
    public void setContador(final int contador){
    	this.contador=contador;
    	
    }
    /**
     * Almacena el n�mero de titulares
     * @param titulares
     */
    public void setTitulares(final int titulares){
    	this.titulares=titulares;
    	
    }
    /**
     * Sirve para almacenar a un cliente
     * @param posicion posici�n del vector donde se va a almacenar
     * @param cli datos del cliente
     */
    public void setCliente(final int posicion, final Cliente cli){
    	this.clientes[posicion]=cli;
    	
    }
    /**
     * Devuelve los datos de un titular
     * @param posicion posici�n del vector donde est� almacenado el titular
     * @return titular
     */
    public Cliente getCliente(final int posicion){
    	return this.clientes[posicion];
    }
    /**
     * Es una variable auxiliar
     * @return
     */
    public int getNumero(){
    	return this.numero;
    }
    /**
     * ver el saldo de una cuenta
     * @return saldo de la cuenta
     */
    public float getSaldo(){ 
    	return saldo;
    }
    /**
     * Almacena el saldo de una cuenta
     * @param saldo
     */
    public void setSaldo(final float saldo){
    	this.saldo=saldo;
    	
    }
    /**
     * Devuelve un titular pasandole el par�metro de la posicion del cliente
     * @param posicion
     * @return
     */
    public String getTCliente(final int posicion){
    	return this.clientes[posicion].getCliente();
    }
/**
 * devuelve el tipo y el n�mero de cuenta
 * @return
 */
    public abstract String getCuenta(); 
/**
 * Sirve para ingresar un importe
 * @param importe (euros)
 */
    public abstract void ingresar(float importe); 
/**
 * Sirve para sacar un importe
 * @param importe --> es en euros
 * @return el importe que hemos sacado
 */
    public abstract float sacar(float importe); 
/**
 * Es un m�todo que sirve para agregar un cliente
 * @param cliente posici�n en memoria de ese cliente
 */
 	public void agregarCliente(final Cliente cliente) {//a�adir el cliente
		
		if(this.titulares>(TITULARES-1)){//Si hay 4 titulares no lo a�ade
			sysout("No se puede a�adir otro titular. Alcanzado el m�ximo");
		} else{
			for (int i=0; i<this.titulares; i++){
				if (this.clientes[i]==cliente){//no agregar un cliente que ya est� asignado a la cuenta
					sysout("Ese cliente ya est� en la cuenta");
					return;
				}
			}
			setCliente(this.titulares,cliente);//agrega el nuevo cliente
			this.titulares++;//suma uno m�s
		}
		
 	}
/**
 * M�todo que se utiliza para borrar un titular
 * @param cliente
 */
   	public void eliminarCliente(final Cliente cliente) {
		
		boolean titular=true;
		if(this.titulares<MINTITULARES){//no borrar si hay un solo cliente;
			sysout("No se puede borrar el titular. No hay titulares o solo hay uno");
		} else{
			for (int i=0;i<this.titulares;i++){//busca el cliente
				if (this.clientes[i]==cliente){//si lo encuentra se borra
					for (int j=i;j<this.titulares-1;j++){//se mueven hacia arriba los que haya debajo
						this.clientes[j]=this.clientes[j+1];
					}
					this.clientes[titulares-1]=null;//el �ltimo se anula
					this.titulares--;//se descuenta 1
					titular=false;
					break;
				}
			}
			if(titular){//para cuando el cliente no estaba
				sysout("El titular no figuraba en esta cuenta");
			}	
		}
		
	}
   	/**
	 * M�todo par imprimir por pantalla
	 * @param frase parametro donde se recibe lo que se va a imprimir por pantalla.
	 */
	public static void sysout(final String frase){
		System.out.println(frase);
	}
/**
 * M�todo abstracto que se impolementa en las clases que heredan de Cuenta
 * @return float con la liquidaci�n mensual
 */
    public abstract float liquidacionMensual(); // se lanza una vez al mes
/**
 * ver el contenido de las cuentas del banco para sacarlo por pantalla
 * @return todos los datos de la cuenta por pantalla
 */
    public abstract String imprimirCuentas(); 

}