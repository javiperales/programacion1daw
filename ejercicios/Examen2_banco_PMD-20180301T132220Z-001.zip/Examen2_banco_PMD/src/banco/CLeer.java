package banco;

import java.io.*;
/**
 * Clase Leer
 * @author Jose Ram�n Casado Solana (PMD)
 *
 */

public final class CLeer {
	/**
	 * frase que se repite
	 */
	private final static String PEDIR="Vuelve a inroducir el dato, por favor: ";
	private CLeer(){

	}

	/**
	 * M�todo par imprimir por pantalla
	 * @param frase parametro donde se recibe lo que se va a imprimir por pantalla.
	 */

	public static void sysout(final String frase){
		System.out.println(frase);
	}
	/**
	 * Pedir cadena de texto
	 * @param texto texto por pantalla al invocar este m�todo
	 * @return String
	 */
	static public String pedirCadena(final String texto) {
		final	BufferedReader dataIn = new BufferedReader(new InputStreamReader(
				System.in));
		String dato="";
		boolean error = true;
		while (error) {
			try {
				sysout(texto);
				dato = dataIn.readLine();
				error=false;
			} catch (IOException e) {
				sysout(PEDIR);
				error = true;
			}
		}
		return dato;

	}
	/**
	 * Es un m�todo para introducir un entero por teclado capturando errores
	 * @param texto por pantalla al invocar este m�todo
	 * @return int
	 */
	static public int pedirEnteroValidar(final String texto) {
		final	BufferedReader dataIn = new BufferedReader(new InputStreamReader(
				System.in));
		int dato=0;
		boolean error = true;
		while (error) {
			try {
				sysout(texto);
				dato = Integer.parseInt(dataIn.readLine());
				error=false;
			} catch (IOException e) {
				sysout(PEDIR);
				error = true;
			} catch(NumberFormatException e){
				sysout("El dato introducido no es entero");
				sysout(PEDIR);
				error=true;
			}
		}
		return dato;

	}
	/**
	 * Es un metodo que caputura un double por teclado filtrando errores
	 * @param texto texto por pantalla al invocar este m�todo
	 * @return
	 */
	static public double decimal(final String texto) {
		final	BufferedReader dataIn = new BufferedReader(new InputStreamReader(
				System.in));
		double dato=0;
		boolean error = true;
		while (error) {
			try {
				sysout(texto);
				dato = Double.parseDouble(dataIn.readLine());
				error=false;
			} catch (IOException e) {
				sysout(PEDIR);
				error = true;
			} catch(NumberFormatException e){
				sysout("El dato introducido no es decimal");
				sysout(PEDIR);
				error=true;
			}
		}
		return dato;

	}
	/**
	 * Metodo para pedir un float por teclado
	 * @param texto texto por pantalla al invocar este m�todo
	 * @return
	 */
	static public float pedirFloat(final String texto) {
		final	BufferedReader dataIn = new BufferedReader(new InputStreamReader(
				System.in));
		float dato=0;
		boolean error = true;
		while (error) {
			try {
				sysout(texto);
				dato = Float.parseFloat(dataIn.readLine());
				error=false;
			} catch (IOException e) {
				sysout(PEDIR);
				error = true;
			} catch(NumberFormatException e){
				sysout("El dato introducido no es entero");
				sysout(PEDIR);
				error=true;
			}
		}
		return dato;

	}


}
