package banco;
/**
 * Clase donde se almacenan los datos de los clientes
 * @author Jose Ram�n Casado Solana (PMD)
 *
 */
class Cliente {
	/**
	 * Atributos del cliente:
	 * dni: Documento nacional de Identidad
	 * nombre: Nombre del cliente
	 * apellidos: Apellido o apellidos del cliente
	 * direccion: Direcci�n del cliente
	 * telefono: tel�fono del cliente
	 */
    private String dni, nombre, apellidos, direccion, telefono;
   /**
    * Constructor del cliente
    * @param nombre nombre del cliente
    * @param apellidos apellidos del cliente
    */
    public Cliente ( final String nombre, final String apellidos ) {
        this.nombre = nombre;
        this.apellidos=apellidos;
    }
/**
 * Metodo para obtener el nombre y apellido del cliente
 * @return
 */
	public String getCliente() {
		return nombre+" "+apellidos;
	}
	/**
	 * M�todo para obtener el dni del cliente
	 * @return dni
	 */
	public String getDni() {
		return dni;
	}
	/**
	 * M�todo que sirve para introducir el dni del cliente
	 * @param dni
	 */
	public void setDni(final String dni) {
		this.dni = dni;
	}
/**
 * Metodo para obtener el nombre del cliente
 * @return nombre del cliente
 */
	public String getNombre() {
		return nombre;
	}
/**
 * Metodo para almacenar el nombre del cliente
 * @param nombre
 */
	public void setNombre(final String nombre) {
		this.nombre = nombre;
	}
/**
 * M�todo para obtener los apellidos del cliente
 * @return apellidos
 */
	public String getApellidos() {
		return apellidos;
	}
/**
 * Metodo para almacenar los apellidos del cliente
 * @param apellidos
 */
	public void setApellidos(final String apellidos) {
		this.apellidos = apellidos;
	}
/**
 * Metodo para obtener la direcci�n del cliente
 * @return direccion del cliente
 */
	public String getDireccion() {
		return direccion;
	}
/**
 * M�todo para almacenar la direcci�n del cliente
 * @param direccion
 */
	public void setDireccion(final String direccion) {
		this.direccion = direccion;
	}
/**
 * Metodo para obtener el n�mero de telefono del cliente
 * @return
 */
	public String getTelefono() {
		return telefono;
	}
/**
 * M�todo para almacenar el t�lefono del cliente
 * @param telefono
 */
	public void setTelefono(final String telefono) {
		this.telefono = telefono;
	}

}
