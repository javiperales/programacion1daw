package banco;
/**
 * @author yo
 *
 */
public class FondoInversion extends AbstractCuenta {
	/**
	 * Interes 0.36% anual
	 */
	private static float interes=0.0036f; //En porcentaje
	/**
	 * Comision 0.6� mensual
	 */
    private static float comision=0.6f; // En euros
    /**
     * Estado de la cuenta
     * true bloqueada
     * false desbloqueada
     */
    private transient boolean bloqueada;

	/**
	 * 
	 */
	public FondoInversion() {
		super();
	}
/**
 * Constructor con parametros
 * @param cliente
 */
	public FondoInversion(final Cliente cliente){
		super();
		super.setCliente(0, cliente);
		this.titulares=1;
		bloqueada=false;
	}
	
/**
 * Ver tipo y numero de cuenta
 */
	@Override
	public String getCuenta() {
		// TODO Auto-generated method stub
		return "Fondo Inversi�n "+super.getNumero();
	}

	/**
	 * Ingresar en la cuenta
	 */
	@Override
	public void ingresar(final float importe) {

		super.setSaldo(super.getSaldo()+importe);
		bloqueada=false;
		
	}

	/**
	 * Sacar del fondo de inversion
	 */
	@Override
	public float sacar(final float importe) {
		float imp;
		imp=importe;
		if(super.getSaldo()-imp<-500){
			imp=500+super.getSaldo();
			System.out.println("No hay importe suficiente. Solo sacar� "+imp);
			bloqueada=true;
		}
		super.setSaldo(super.getSaldo()-imp);
		return imp;
	}

	/**
	 * Liquidacion mensual
	 */
	@Override
	public float liquidacionMensual() {
		
		float interesMes;
		interesMes=super.getSaldo()*(this.interes/12)-this.comision;
		if(interesMes<0){
			sacar(-interesMes);
		}else {
			ingresar(interesMes);
		}
		return interesMes;

	}

	/**
	 * Imprime informacion de la cuenta
	 */
	@Override
	public String imprimirCuentas() {
		// TODO Auto-generated method stub
		return "N�mero de cuenta "+super.getNumero()+", Titular 0 "+super.getTCliente(0)+", Fondo Inversi�n - saldo: "+super.getSaldo()+" , "+bloqueada;
	}
}