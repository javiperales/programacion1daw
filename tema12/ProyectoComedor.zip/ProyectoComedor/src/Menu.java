
public class Menu {
	private Plato[] platos;

	public Menu(Plato[] platos) {
		
		this.platos = platos;
		
	}
	
	
	
}
