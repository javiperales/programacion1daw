import java.util.ArrayList;
import java.util.TreeSet;

public class comedor {

	public static void main(String[] args) {
		/////////////principal//////


		TreeSet<Ingrediente> setIngredientes = new TreeSet<Ingrediente>();
		ArrayList<Plato> listaPlatos = new ArrayList<Plato>();
		Mesa[] mesas= new Mesa[10];
		Plato[] carta = new Plato[6];
		
	}//main
	
	public static void creaIngredientes(TreeSet<Ingrediente> setIngredientes){
		
	}//creaIngredientes
	
	public static void creaListaPlatos(ArrayList<Plato> listaPlatos){
		
	}
	
	public static Plato[] creaCarta(ArrayList<Plato> listaPlatos){
		Plato[] carta = new Plato[6];
		
		
		return carta;
	}//creaCarta
	
	public static Mesa[] creaMesas(Plato[] carta ){
		Mesa[] mesas= new Mesa[10];
		
		
		return mesas;
	}

}//class
