import java.util.ArrayList;
import java.util.TreeSet;

public class comedor {

	public static void main(String[] args) {
		/////////////principal//////


		TreeSet<Ingrediente> setIngredientes = new TreeSet<Ingrediente>();
		ArrayList<Plato> listaPlatos = new ArrayList<Plato>();
		Mesa[] mesas= new Mesa[10];
		Plato[] carta = new Plato[6];
		Menu[] menues= null;
		
		listaPlatos=creaListaPlatos(listaPlatos);
		//System.out.println(listaPlatos.get(Libreria.a_enteroAzar(0, 15)));
		carta = creaCarta(listaPlatos);
		System.out.println(listaPlatos);
		menues = creaMenu(listaPlatos);
		System.out.println(listaPlatos);
		mesas = creaMesas( carta , menues ,listaPlatos);
		
	}//main
	
	public static TreeSet<Ingrediente> creaIngredientes(TreeSet<Ingrediente> setIngredientes){
		 String ingredienteAzar=Libreria.a_ingredientesAzar();
		 Integer precioAzar=Libreria.a_enteroAzar(1, 5)+1;
		Ingrediente ingredientes;
		ingredientes = new Ingrediente(ingredienteAzar,precioAzar);
		
		for(int i=0; i<Libreria.a_ingredientesAzar().length();i++){
		setIngredientes.add(ingredientes);
		}
		return setIngredientes;
	}//creaIngredientes
	
	public static ArrayList<Plato> creaListaPlatos(ArrayList<Plato> listaPlatos){
		Plato miPlato;
		String nombrePlato;
		
		for(int i=0; i<15; i++){
			 Integer precioAzar=Libreria.a_enteroAzar(1, 5);
				nombrePlato=Libreria.a_ingredientesAzar()+" con "+Libreria.a_ingredientesAzar();
			miPlato = new Plato(nombrePlato,precioAzar+1);
			listaPlatos.add(miPlato);		
			
		}
		return listaPlatos;
		
	}
	
	public static Plato[] creaCarta(ArrayList<Plato> listaPlatos){
		Plato[] carta = new Plato [6];
		for(int i=0; i<6;i++){
			carta[i]=listaPlatos.get(Libreria.a_enteroAzar(1, 15));
		}//for
							
		return carta;
	}//creaCarta
	
	
	public static Menu[] creaMenu(ArrayList<Plato> listaPlatos){
		Menu[] menues = null;
		
			for(int i=0; i<=1;i++){
				menues[i]= new Menu(creaCarta(listaPlatos));
			}
		
		return menues; 
	}//creaMenu
	
	
	public static Mesa[] creaMesas(Plato[] carta ,Menu[] menues ,ArrayList<Plato> listaPlatos){
		Mesa[] mesas =null;
		//Menu[] menues = null;
			
		for(int i=0;i<10;i++){
			
			mesas[i] = new Mesa(i,creaMenu(listaPlatos));
			System.out.println(mesas[i]);
		}
		
		
		return mesas;
	}//creaMesas

}//class
