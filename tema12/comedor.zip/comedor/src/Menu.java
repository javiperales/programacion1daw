import java.util.Arrays;

public class Menu {
	private Plato[] platos;

	public Menu(Plato[] platos) {
		
		this.platos = platos;
		
	}//constructor

	public Plato[] getPlatos() {
		return platos;
	}

	public void setPlatos(Plato[] platos) {
		this.platos = platos;
	}

	@Override
	public String toString() {
		return "Menu [platos=" + Arrays.toString(platos) + "]";
	}
	
	
	
	
	
}
